

<?php $__env->startSection('content'); ?>
    <div class="body">
        <div class="bf">
            <h1>Tìm kiếm: <?php echo e($search); ?></h1>
        </div>

        <div class="container">

            <?php if(count($Sachs) == 0): ?>
                <p class="text-center">Không có sản phẩm nào phù hợp với từ khóa được tìm kiếm</p>
            <?php else: ?> <div class="row gtf">
                    <?php $__currentLoopData = $Sachs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 card gt">
                            <a href="<?php echo e(url('home/detail/' . $Sach->STT)); ?>"><img
                                    src="<?php echo e(Storage::disk('AnhSach')->url($Sach->AnhSP)); ?>" class="card-img-top"
                                    alt="..."></a>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($Sach->TenSach); ?></h5>
                                <p class="card-text"><span><?php echo e(number_format($Sach->DonGia, 0, '', '.')); ?></span> VNĐ
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div>
                    <?php echo e($Sachs->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/web/Search.blade.php ENDPATH**/ ?>