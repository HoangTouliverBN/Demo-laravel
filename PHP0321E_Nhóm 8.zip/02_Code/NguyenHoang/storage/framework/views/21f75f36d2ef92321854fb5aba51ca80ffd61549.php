<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('vendors/reset200802.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/normalize.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" />
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/login-register.css')); ?>">
</head>

<body>
    <?php if(\Session::has('message')): ?>
        <div class="position-fixed">
            <div class="toast" role="alert" aria-live="assertive" aria-atomic="true" data-delay="10000">
                <div class="toast-header">
                    <span class="bell-customed"><i class="far fa-bell"></i></span>
                    <strong class="mr-auto">Thông báo</strong> 
                    
                    <small class="text-muted toast-customed">hiện tại</small>
                    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="toast-body">
                    <?php echo e(\Session::get('message')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <?php echo $__env->make('web._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldContent('content'); ?>
    
    <?php echo $__env->make('web._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"
        integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
    <?php if(\Session::has('message')): ?>
        <script>
            $(document).ready(function() {
                $('.toast').toast('show');
            });
        </script>
    <?php endif; ?>

    <?php if(isset($shoppingCart)): ?>
        <script>
            $(function() {
                function formatNumber(num) {
                    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.')
                }
                let $tong_gia = 0;
                let $tong_soluong = 0;
                <?php $__currentLoopData = $shoppingCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    let $thanh_tienss<?php echo e($cart->id); ?> = 0;
                    let a<?php echo e($cart->id); ?> = 0
                
                    $('input#input-number-<?php echo e($cart->id); ?>').change(function() {
                    let $don_gia = $('#don_gia_<?php echo e($cart->id); ?>').text();
                
                    let $so_luong = $('input#input-number-<?php echo e($cart->id); ?>').val();
                
                    let $thanh_tien<?php echo e($cart->id); ?> = $don_gia * $('input#input-number-<?php echo e($cart->id); ?>').val();
                
                    $('#tong_gia_<?php echo e($cart->id); ?>').val($thanh_tien<?php echo e($cart->id); ?>);
                
                    if($so_luong == 1)
                    {
                    a<?php echo e($cart->id); ?> = $thanh_tien<?php echo e($cart->id); ?>

                    }
                
                    if($thanh_tien<?php echo e($cart->id); ?> > $thanh_tienss<?php echo e($cart->id); ?>)
                    {
                    $thanh_tienss<?php echo e($cart->id); ?> = $thanh_tien<?php echo e($cart->id); ?>;
                
                    $tong_gia = $tong_gia + a<?php echo e($cart->id); ?>;
                
                    $('#price').val($tong_gia);
                
                    }
                
                    if($thanh_tien<?php echo e($cart->id); ?> < $thanh_tienss<?php echo e($cart->id); ?>) {
                        $thanh_tienss<?php echo e($cart->id); ?>=$thanh_tien<?php echo e($cart->id); ?>; $tong_gia=$tong_gia - a<?php echo e($cart->id); ?>;
                        $('#price').val($tong_gia); } }); <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            })
        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/web/index.blade.php ENDPATH**/ ?>