<div class=" col-2 ">
    <div class="nav flex-column nav-pills menu-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">


        <a class=" nav-link border border-primary menu-custom-children"  href="{{ url('quanlysach') }}" role="tab" >Quản lý sách</a>



        <a class=" nav-link border border-primary menu-custom-children"  href="{{ url('quanlytheloai') }}" role="tab">Quản lý thể loại</a>

        <a class=" nav-link border border-primary menu-custom-children"  href="{{ url('quanlyorder') }}" role="tab">Quản lý đơn đăng ký mua hàng</a>

        <a class=" nav-link border border-primary menu-custom-children"  href="{{ url('quanlyuser') }}" role="tab">Quản lý người dùng</a>

        <a class=" nav-link border border-primary menu-custom-children"  href="{{ url('shoppingCart') }}" role="tab">Quản lý giỏ hàng</a>

        <a class=" nav-link border border-primary menu-custom-children"  href="{{ url('quanlydoanhthu') }}" role="tab">Quản lý doanh thu</a>
    </div>
</div>
