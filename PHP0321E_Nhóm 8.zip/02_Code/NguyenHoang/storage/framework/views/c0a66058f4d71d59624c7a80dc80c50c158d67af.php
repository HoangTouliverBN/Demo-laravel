

<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="text-center">Thông tin chi tiết</h1>
<div >
<?php if($quanlyuser == null): ?>
    <p>Người dùng chưa cập nhật thông tin cá nhân</p>
<?php else: ?>
<div>
    <h3>Tài khoản:</h3>
    <p><?php echo e($quanlyuser->email); ?></p>
</div>

<div>
    <h3>Họ và tên:</h3>
    <p><?php echo e($quanlyuser->last_name); ?> <?php echo e($quanlyuser->first_name); ?></p>
</div>

<div>
    <h3>Ngày sinh:</h3>
    <p><?php echo e($quanlyuser->birthday); ?></p>
</div>

<div>
    <h3>Số điện thoại:</h3>
    <p><?php echo e($quanlyuser->phone_number); ?></p>
</div>

<div>
    <h3>Địa chỉ:</h3>
    <p><?php echo e($quanlyuser->address); ?></p>
</div>

<?php endif; ?>

    <a href="<?php echo e(url('quanlyuser')); ?>" class="btn btn-primary">Quay lại</a>
</div>    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/backend/quanlyuser/show.blade.php ENDPATH**/ ?>