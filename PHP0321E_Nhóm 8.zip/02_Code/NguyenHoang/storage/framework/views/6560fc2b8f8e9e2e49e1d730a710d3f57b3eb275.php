

<?php $__env->startSection('content'); ?>
    <div class="body">
        <div class="bf">
            <h1>SÁCH VĂN HỌC </h1>
            <div class="top-design">
                <img class="grid" src="./assets/images/grid.png" alt=""><a href="<?php echo e(url('home/vanhoc')); ?>"><img
                        class="xemthem" src="./assets/images/xemthem.png" alt=""></a>
            </div>
        </div>

        <div class="container">
            <div class="row gtf">
                <?php $__currentLoopData = $VanHoc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SachVanHoc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 card gt">
                        <a href="<?php echo e(url('home/detail/' . $SachVanHoc->STT)); ?>"><img
                                src="<?php echo e(Storage::disk('AnhSach')->url($SachVanHoc->AnhSP)); ?>"
                                class="card-img-top card-product" alt="..."></a>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($SachVanHoc->TenSach); ?></h5>
                            <p class="card-text"><span><?php echo e(number_format($SachVanHoc->DonGia, 0, '', '.')); ?></span>
                                VNĐ
                            </p>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>

    <div class="body">
        <div class="bf">
            <h1>SÁCH TÂM LÝ </h1>
            <div class="top-design">
                <img class="grid" src="./assets/images/grid.png" alt=""><a href="<?php echo e(url('home/tamly')); ?>"><img
                        class="xemthem" src="./assets/images/xemthem.png" alt=""></a>
            </div>
        </div>

        <div class="container">
            <div class="row gtf">
                <?php $__currentLoopData = $TamLy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SachTamLy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 card gt">
                        <a href="<?php echo e(url('home/detail/' . $SachTamLy->STT)); ?>"><img
                                src="<?php echo e(Storage::disk('AnhSach')->url($SachTamLy->AnhSP)); ?>"
                                class="card-img-top card-product" alt="..."></a>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($SachTamLy->TenSach); ?></h5>
                            <p class="card-text"><span><?php echo e(number_format($SachTamLy->DonGia, 0, '', '.')); ?></span>
                                VNĐ
                            </p>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="body">
            <div class="bf">
                <h1>SÁCH KHÁC </h1>
                <div class="top-design">
                    <img class="grid" src="./assets/images/grid.png" alt=""><a
                        href="<?php echo e(url('home/khac')); ?>"><img class="xemthem" src="./assets/images/xemthem.png"
                            alt=""></a>
                </div>
            </div>

            <div class="container">
                <div class="row gtf">
                    <?php $__currentLoopData = $Khac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SachKhac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 card gt">
                            <a href="<?php echo e(url('home/detail/' . $SachKhac->STT)); ?>}}"><img
                                    src="<?php echo e(Storage::disk('AnhSach')->url($SachKhac->AnhSP)); ?>" class="card-img-top card-product"
                                    alt="..."></a>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($SachKhac->TenSach); ?></h5>
                                <p class="card-text">
                                    <span><?php echo e(number_format($SachKhac->DonGia, 0, '', '.')); ?></span>
                                    VNĐ
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="content">
            <p>ĐỌC SÁCH CHO TA KIẾN THỨC VÀ SỰ HIỂU BIẾT…
            </p>
            <div class="imgcontent">
                <img src="./assets/images/Anh7.png" alt="">
            </div>
        </div>
        </h1>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/web/section.blade.php ENDPATH**/ ?>