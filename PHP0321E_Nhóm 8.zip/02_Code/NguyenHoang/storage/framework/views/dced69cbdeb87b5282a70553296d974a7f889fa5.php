

<?php $__env->startSection('content'); ?>
<div class="body">
    <div class="bf">
        <h1><?php echo e($TheLoai); ?> </h1>
    </div>

    <div class="container">
        <div class="row  gtf">
            <?php $__currentLoopData = $Sachs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 card gt">
                <a href="<?php echo e(url('home/detail/'.$Sach->STT)); ?>"><img src="<?php echo e(Storage::disk('AnhSach')->url($Sach->AnhSP)); ?>" class="card-img-top detail-product" alt="..."></a>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($Sach->TenSach); ?></h5>
                    <p class="card-text"><span><?php echo e(number_format($Sach->DonGia,0,"",".")); ?></span> VNĐ</p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/web/ShowAll.blade.php ENDPATH**/ ?>