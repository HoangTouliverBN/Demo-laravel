

<?php $__env->startSection('content'); ?>
    <div class="tab-pane fade show active" id="quanlyorder" role="tabpanel" aria-labelledby="v-pills-home-tab">
        <div>
            <div>
                <h1 class="text-center">Quản lý giỏ hàng</h1>
            </div><br>

            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th scope="col">Email</th>

                        <th scope="col">Tên sản phẩm</th>

                        <th scope="col">Số lượng</th>

                        <th scope="col">Tình trạng</th>

                        <th scope="col">Ngày thanh toán</th>

                        


                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $shoppingCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($cart->email); ?></td>
                            <td scope="row"><?php echo e($cart->TenSach); ?></td>
                            <td scope="row"><?php echo e($cart->so_luong); ?></td>
                            <td scope="row"><?php echo e($cart->state != null ? 'Đã thanh toán' : 'Chưa thanh toán'); ?></td>
                            <td scope="row"><?php echo e($cart->state != null ? $cart->updated_at : ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($shoppingCart->links('pagination::bootstrap-4')); ?>

        </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/backend/shoppingCart/index.blade.php ENDPATH**/ ?>