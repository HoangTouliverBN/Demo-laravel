

<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(url('quanlysach/'.$quanlysach->STT)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="MS">Mã sách:</label>
            <input type="text" name="MS" class="form-control" id="MS" value="<?php echo e($quanlysach->MS); ?>">
            <p class="error"><?php $__errorArgs = ['MS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
        </div>

        <div class="form-group">
            <label for="TenSach">Tên sách:</label>
            <input type="text" name="TenSach" class="form-control" id="TenSach" value="<?php echo e($quanlysach->TenSach); ?>">
            <p class="error"><?php $__errorArgs = ['TenSach'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>

        </div>

        <div class="form-group">
            <label for="TacGia">Tác giả:</label>
            <input type="text" name="TacGia" class="form-control" id="TacGia" value="<?php echo e($quanlysach->TacGia); ?>">
            <p class="error"><?php $__errorArgs = ['TacGia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>

        </div>

        <div class="form-group">
            <label for="NSB">Nhà xuất bản:</label>
            <input type="text" name="NSB" class="form-control" id="NSB" value="<?php echo e($quanlysach->NSB); ?>">
            <p class="error"><?php $__errorArgs = ['NSB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>

        </div>

        <div class="form-group">
            <label for="TheLoai">Thể loại:</label>
            <select name="TheLoai" id="TheLoai" class="form-control">
                <option value="<?php echo e($quanlysach->TheLoai); ?>"><?php echo e($quanlysach->TheLoai); ?></option>
                <option value="Văn học">Văn học</option>
                <option value="Tâm lý">Tâm lý</option>
                <option value="khác">Khác</option>
            </select>

            <p class="error">
                <?php $__errorArgs = ['TheLoai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </p>

        </div>

        <div class="form-group">
            <label for="DonGia">Đơn giá</label>
            <input type="number" name="DonGia" class="form-control" id="DonGia" value="<?php echo e($quanlysach->DonGia); ?>">
            <p class="error"<?php $__errorArgs = ['DonGia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>></p>

        </div>

        <div class="form-group">
            <label for="SoLuong">Số lượng</label>
            <input type="number" name="SoLuong" class="form-control" id="SoLuong" value="<?php echo e($quanlysach->SoLuong); ?>">
            <p class="error"><?php $__errorArgs = ['SoLuong'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
        </div>

        <div class="form-group">
            <label for="AnhSP">Ảnh sản phẩm</label>
            <input type="file" name="AnhSP" class="form-control" id="AnhSP" value="<?php echo e($quanlysach->AnhSP); ?>">
            <p class="error">
                <?php $__errorArgs = ['AnhSP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </p>
            <div>
                <img src="<?php echo e(Storage::disk('AnhSach')->url($quanlysach->AnhSP)); ?>" alt="">
            </div>
        </div>


        <button type="submit" name="submit" class="btn btn-primary">Cập nhật</button>
        <a href="<?php echo e(url('quanlysach')); ?>" class="btn btn-primary">Quay lại</a>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/quanlysach/edit.blade.php ENDPATH**/ ?>