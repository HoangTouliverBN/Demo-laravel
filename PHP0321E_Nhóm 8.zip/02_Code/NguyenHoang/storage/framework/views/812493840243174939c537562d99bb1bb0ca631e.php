

<?php $__env->startSection('content'); ?>
    <div class="tab-pane fade show active" id="quanlyorder" role="tabpanel" aria-labelledby="v-pills-home-tab">
        <div>
            <div>
                <h1 class="text-center">Đơn đăng ký mua hàng</h1>
            </div><br>

            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th scope="col">Tên sản phẩm</th>

                        <th scope="col">Tài khoản đăng ký</th>

                        <th scope="col">Số điện thoại</th>

                        <th scope="col">Tình trạng</th>

                        <th scope="col"></th>


                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($order->name); ?></td>
                            <td scope="row"><?php echo e($order->email); ?></td>
                            <td scope="row"><?php echo e($order->phone_number); ?></td>
                            <td scope="row"><?php echo e($order->state == null ? 'Chưa hoàn thành' : 'Đã hoàn thành'); ?></td>
                            <td>
                                <form action="<?php echo e(url('quanlyorder/state/' . $order->id)); ?>" method="POST"
                                    class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    
                                    <input type="text" value='<?php echo e($order->state == null ? $order->id : null); ?>'
                                        name="state" class="d-none">
                                    <button type="submit" style="border: none;
                                        background-color: WHITE; color:#007bff;"><?php echo $order->state == null ? '<i class="fas fa-check"></i>' : '<i class="fas fa-times"></i>'; ?></button>
                                </form>


                                <a href="<?php echo e(url('quanlyorder/' . $order->id)); ?>"><i class="far fa-eye"></i></a>
                                <a href="<?php echo e(url('quanlyorder/' . $order->id . '/edit')); ?>"><i
                                        class="fas fa-pencil-alt"></i></a>
                                <form action="<?php echo e(url('quanlyorder/' . $order->id)); ?>" class="d-inline" method="POST"
                                    onsubmit="return confirm('Bạn có chắc chắn xóa')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" style="border: none;
                                    background-color: WHITE; color:#007bff;"><i class="fas fa-trash"></i></a></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($orders->links('pagination::bootstrap-4')); ?>

        </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/backend/quanlyorder/index.blade.php ENDPATH**/ ?>