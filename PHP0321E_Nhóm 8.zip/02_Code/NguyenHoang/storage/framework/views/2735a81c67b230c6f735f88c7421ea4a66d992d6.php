

<?php $__env->startSection('content'); ?>
    <div class="tab-pane fade show active" id="quanlytheloai" role="tabpanel" aria-labelledby="v-pills-home-tab">
        <div>
            <div>
                <h1 class="text-center">Thể loại sản phẩm</h1>
                <div>
                    <a href="<?php echo e(url('quanlytheloai/create')); ?>" class="btn btn-success">+ Thêm mới</a>
                </div>
            </div><br>

            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th scope="col">Thể loại</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $theLoaiSach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theloai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($theloai->TheLoai); ?></td>
                            <td>
                                <a href="<?php echo e(url('quanlytheloai/' . $theloai->id)); ?>"><i class="far fa-eye"></i></a>
                                <a href="<?php echo e(url('quanlytheloai/' . $theloai->id . '/edit')); ?>"><i
                                        class="fas fa-pencil-alt"></i></a>
                                <a href="<?php echo e(url('quanlytheloai/' . $theloai->id)); ?>"
                                    onclick="return confirm('Bạn có chắc chắn muốn xóa dữ liệu này?')"></a>
                                <form action="<?php echo e(url('quanlytheloai/' . $theloai->id)); ?>" class="d-inline" method="POST"
                                    onsubmit="return confirm('Bạn có chắc chắn xóa')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" style="border: none;
                            background-color: WHITE; color:#007bff;"><i class="fas fa-trash"></i></a></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($theLoaiSach->links('pagination::bootstrap-4')); ?>

        </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/backend/quanlytheloai/index.blade.php ENDPATH**/ ?>