

<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="text-center">Thông tin chi tiết</h1>
<div >
    <div>
        <h3>Tên sản phẩm</h3>
        <p><?php echo e($quanlyorder->name); ?></p>
    </div>

    <div>
        <h3>Tài khoản đăng ký</h3>
        <p><?php echo e($quanlyorder->email); ?></p>
    </div>

    <div>
        <h3>Họ và tên</h3>
        <p><?php echo e($quanlyorder->last_name); ?> <?php echo e($quanlyorder->first_name); ?></p>
    </div>

    <div>
        <h3>Số điện thoại</h3>
        <p><?php echo e($quanlyorder->phone_number); ?></p>
    </div>

    <div>
        <h3>Địa chỉ</h3>
        <p><?php echo e($quanlyorder->address); ?></p>
    </div>

    <div>
        <h3>Tình trạng</h3>
        <p><?php echo e($quanlyorder->state == null ? 'Chưa hoàn thành' : 'Đã hoàn thành'); ?></p>
    </div>

    <div>
        <h3>Link sản phẩm</h3>
        <p><?php echo e($quanlyorder->link != null ? $quanlyorder->link : 'Chưa có'); ?></p>
    </div>

    <div>
        <h3>Ghi chú</h3>
        <p><?php echo e($quanlyorder->description); ?></p>
    </div>

    <div>
        <h3>Ảnh sản phẩm</h3>
        <?php if(!empty($quanlyorder->img)): ?>
        <p><img src="<?php echo e(Storage::disk('ImgOrder')->url($quanlyorder->img)); ?>" alt=""></p>
            
        <?php else: ?>
        <p>Chưa có</p>
        <?php endif; ?>
        
    </div>


    <a href="<?php echo e(url('quanlyorder')); ?>" class="btn btn-primary">Quay lại</a>
</div>    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/backend/quanlyorder/show.blade.php ENDPATH**/ ?>