

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Giỏ hàng của <?php echo e(Auth::user()->name); ?></h1>

        <?php if(count($shoppingCart) == 0): ?>
            <p>Không có sản phẩm nảo trong giỏ hàng của bạn</p>
        <?php else: ?>
            <form action="<?php echo e(url('/shoppingCart/pay')); ?>" method="POST" id="form-pay">
                <?php echo csrf_field(); ?>
                <table class="table table-bordered ">
                    <thead>
                        <tr>
                            <th scope="col-15">Ảnh sản phẩm</th>

                            <th scope="col">Tên sản phẩm</th>

                            <th scope="col">Đơn giá</th>

                            <th scope="col">Số lượng</th>

                            <th scope="col">Thành tiền</th>

                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $shoppingCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr scope="row">
                                <td class="shopping-cart-text"><img src="<?php echo e(Storage::disk('AnhSach')->url($cart->AnhSP)); ?>"
                                        class="table-img" alt="..."></td>
                                <td class="shopping-cart-text"><?php echo e($cart->TenSach); ?></td>
                                <td class="shopping-cart-text" id="don_gia_<?php echo e($cart->id); ?>"><?php echo e($cart->DonGia); ?></td>
                                <td class="shopping-cart-text">
                                    <input type="number" class="form-controll input-number"
                                        id="input-number-<?php echo e($cart->id); ?>" name='so_luong[]' 
                                        onkeydown="return false"  value="" min="1"
                                        max="100">
                                </td>
                                <td class="shopping-cart-text"><input id="tong_gia_<?php echo e($cart->id); ?>" type="number"
                                        disabled value="" name="tong_gia<?php echo e($cart->id); ?>">
                                </td>
                                <td class="shopping-cart-text">
                                    <a href="<?php echo e(url('shoppingCart/delete/' . $cart->id)); ?>" id="btn-delete" style="border: none;
                                            background-color: WHITE; color:#007bff;"><i class="fas fa-trash"></i>
                                        <a>
                                </td>
                                <input type="number" class="d-none" readonly value="<?php echo e($cart->id); ?>"
                                    name="id[]">
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="text-right">
                    <p class="d-inline">Tổng tiền đơn hàng: <input type="number" name="money" id='price' readonly></p>
                    <button type="submit" class='btn btn-primary'>Thanh toán</button>
                </div>
            </form>
        <?php endif; ?>
        <p class="error"> <?php $__errorArgs = ['so_luong[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/web/ShoppingCart.blade.php ENDPATH**/ ?>