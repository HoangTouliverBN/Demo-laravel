
<?php $__env->startSection('content'); ?>
    <div class="bg-light text-dark resetPassword">
        <form action="<?php echo e(url('password/reset/' . $token)); ?>" class="login-form container" method="POST">
            <?php echo csrf_field(); ?>
            <div class="div-password">
                <div class="form-group">
                    <label for="password">Mật khẩu mới:</label>
                    <input type="password" id="password" name="password" class="form-control">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="confirm-password">Nhập lại mật khẩu:</label>
                    <input type="password" id="confirm-password" name="confirm-password" class="form-control">
                    <?php $__errorArgs = ['confirm-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="text-center ">
                <button type="submit" class="btn-submit btn btn-primary btn-request">Đặt lại mật khẩu</button>
            </div>
            <a href="<?php echo e(url('login')); ?>">Đăng nhập?</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('login-register.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/login-register/resetPassword.blade.php ENDPATH**/ ?>