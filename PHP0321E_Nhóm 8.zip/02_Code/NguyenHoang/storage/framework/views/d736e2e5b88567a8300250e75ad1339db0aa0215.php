<header>
    <div class="row navfirst">
        <div class="col-md-6 navl logo-left">
            <h1><a href="<?php echo e(url('home')); ?>">NGUYEN HOANG</a></h1>
            <div>
                <p>Hotline: 1800 1000</p>
            </div>
        </div>

        <div class="col-md-6 navr">
            <ul>
                <li>
                    
                        <?php if(Auth::check()): ?>
                        <a class="btn btn-secondary dropdown-toggle active-user" href="" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-user"></i><span class="inuser"> <?php echo e(Auth::user()->name); ?></span></a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a href="<?php echo e(url('user-information')); ?>" class="dropdown-item DI">Thông tin cá nhân</a>
                            <?php if(Auth::user()->id_phanquyen==2||Auth::user()->id_phanquyen==3): ?>
                            <a class="dropdown-item DI" href="<?php echo e(url('quanlysach')); ?>">Quản lý</a>

                            <?php endif; ?>
                            <?php if(Auth::user()->id_phanquyen==3): ?>
                            <a class="dropdown-item DI" href="<?php echo e(url('register-admin')); ?>">Thêm tài khoản admin</a>
                            <?php endif; ?>
                            <a class="dropdown-item DI" href="<?php echo e(url('changePassword')); ?>">Đổi mật khẩu</a>
                            <a class="dropdown-item DI" href="<?php echo e(url('logout')); ?>">Đăng xuất</a>
                        </div>
                        <?php else: ?>
                        <a href="<?php echo e(url('login')); ?>" class="btn btn-default btn-rounded my-3 user" ><i class="fas fa-user"></i><span class="inuser">Tài khoản</span></a>
                        <?php endif; ?>

                </li>
            </ul>
        </div>
    </div>

    
</header>


<?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/login-register/_header.blade.php ENDPATH**/ ?>