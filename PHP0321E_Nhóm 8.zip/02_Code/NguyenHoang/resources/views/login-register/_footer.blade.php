<footer>
    <div class="container">
        <div class="contact row">
            <div class="col-md-5 fl">
                <h1><a id="nh" href="#">NGUYENHOANG.com</a></h1>
                <p>Địa chỉ: số 1000 Hồ Tùng Mậu, Cầu Giấy, Hà Nội</p>
                <p> NGUYENHOANG.com nhận đặt hàng trực tuyến và giao hàng tận nơi. KHÔNG hỗ trợ đặt mua và nhận hàng
                    trực
                    tiếp
                    tại văn phòng cũng như tất cả Hệ Thống NGUYENHOANG trên toàn quốc.</p>
                <div>
                    <img src="./assets/images/Anh10.png" alt="">
                </div>
                <div>
                    <ul class="topnav">
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-7 fr">
                <div>
                    <h2>DỊCH VỤ</h2>
                    <ul>
                        <li><a href="#">Điều khoản sử dụng</a></li>
                        <li><a href="#">Chính sách bảo mật</a></li>
                        <li><a href="#">Giới thiệu Fahasa</a></li>
                        <li><a href="#">Hệ thống trung tâm-nhà sách</a></li>
                    </ul>
                </div>
                <div>
                    <h2>HỖ TRỢ</h2>
                    <ul>
                        <li><a href="#">Chính sách đổi-trả-hoàn tiền</a></li>
                        <li><a href="#">Chính sách khách sỉ</a></li>
                        <li><a href="#">Phương thức vận chuyển</a></li>
                        <li><a href="#">Phương thức thanh toán và xuất HĐ</a></li>
                    </ul>
                </div>
                <div>
                    <h2>
                        LIÊN HỆ
                    </h2>
                    <p>Đ/c: số 1000 Hồ Tùng Mậu, Cầu Giấy, Hà Nội
                    </p>
                    <p>
                        Hotline: 18001000
                    </p>
                </div>
            </div>
        </div>

    </div>
</footer>