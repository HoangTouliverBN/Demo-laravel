


<?php $__env->startSection('content'); ?>
<div class="bg-light text-dark login">
    <form action="<?php echo e(url('changePassword')); ?>" class="login-form container" method="POST">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="oldPassword">Mật khẩu cũ:</label>
                <input type="password" id="oldPassword" name="oldPassword" class="form-control">
            </div>

            <?php $__errorArgs = ['oldPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="form-group">
                <label for="Password">Mật khẩu:</label>
                <input type="password" id="Password" name="Password" class="form-control">
            </div>

            <?php $__errorArgs = ['Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="form-group">
                <label for="rePassword">Nhập lại mật khẩu:</label>
                <input type="password" id="rePassword" name="rePassword" class="form-control">
            </div>

            <?php $__errorArgs = ['rePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            <div class="text-center ">
                <button type="submit" class="btn-changePassword btn btn-primary">Đổi mật khẩu</button>
                <a href="<?php echo e(url('home')); ?>" class="btn btn-primary btn-changePassword">Quay lại</a>       
            </div>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('login-register.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/login-register/changePassword.blade.php ENDPATH**/ ?>