

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="bg-light show-detail" >
        <div class="row no-gutters ">
            <div class="col-md-4 text-right ">
                <img class="detail-product" src="<?php echo e(Storage::disk('AnhSach')->url($detail->AnhSP)); ?>" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title">Tên sách: <?php echo e($detail->TenSach); ?></h5>
                    <p class="card-text">Thể loại: <?php echo e($detail->TheLoai); ?></p>
                    <p class="card-text">Mã sách: <?php echo e($detail->MS); ?></p>
                    <p class="card-text">Tác giả: <?php echo e($detail->TacGia); ?></p>
                    <p class="card-text">Nhà suất bản: <?php echo e($detail->NSB); ?></p>
                    <p class="card-text">Giá: <?php echo e(number_format($detail->DonGia,0,"",".")); ?></p>
                    <p class="card-text">Tình trạng: <?php echo e($TinhTrang); ?> </p>
                    <a href="/addIntoShoppingCart/<?php echo e($detail->STT); ?>" class=" btn btn-primary">Thêm vào giỏ hàng</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/web/ShowDetail.blade.php ENDPATH**/ ?>