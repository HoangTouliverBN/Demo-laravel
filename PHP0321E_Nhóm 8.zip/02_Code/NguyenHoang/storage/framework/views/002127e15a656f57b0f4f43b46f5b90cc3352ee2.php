

<?php $__env->startSection('content'); ?>
<div class="">
    <div class="bg-light show-detail" >
        <div class="row no-gutters">
            <div class="col-md-4 text-right">
                <?php if(!empty($value->avatar)): ?>
                <img class="avatar" src="<?php echo e(Storage::disk('Avatar')->url($value->avatar)); ?>" alt="">
                    
                <?php else: ?>
                <img class="w-50" src="<?php echo e(asset('assets/images/avatar.png')); ?>" alt="">
                <?php endif; ?>
                
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title">Họ và tên: <?php echo e($value->last_name ?? ''); ?> <?php echo e($value->first_name ?? ''); ?></h5>
                    <p class="card-title">Ngày sinh: <?php if(isset($value->birthday)): ?>
                        <?php echo e(date('d/m/Y', strtotime($value->birthday)) ?? ''); ?>

                    <?php endif; ?></p>
                    <p class="card-title">Số điện thoại: <?php echo e($value->phone_number ?? ''); ?></p>
                    <p class="card-title">Địa chỉ: <?php echo e($value->address ?? ''); ?></p>
                    <a href="<?php echo e(url('update-information')); ?>" class=" btn btn-primary">Cập nhật thông tin cá nhân</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/user/index.blade.php ENDPATH**/ ?>