

<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="text-center">Thông tin chi tiết</h1>
<div >
    <div>
        <h3>STT</h3>
        <p><?php echo e($quanlysach->STT); ?></p>
    </div>
    
    <div>
        <h3>Mã sách</h3>
        <p><?php echo e($quanlysach->MS); ?></p>
    </div>

    <div>
        <h3>Tên sách</h3>
        <p><?php echo e($quanlysach->TenSach); ?></p>
    </div>

    <div>
        <h3>Tác giả</h3>
        <p><?php echo e($quanlysach->TacGia); ?></p>
    </div>

    <div>
        <h3>Nhà xuất bản</h3>
        <p><?php echo e($quanlysach->NSB); ?></p>
    </div>

    <div>
        <h3>Thể loại</h3>
        <p><?php echo e($quanlysach->TheLoai); ?></p>
    </div>

    <div>
        <h3>Đơn giá</h3>
        <p><?php echo e($quanlysach->DonGia); ?></p>
    </div>

    <div>
        <h3>Số lượng</h3>
        <p><?php echo e($quanlysach->SoLuong); ?></p>
    </div>


    <div>
        <h3>Ngày khởi tạo</h3>
        <p><?php echo e($quanlysach->created_at); ?></p>
    </div>

    <div>
        <h3>Lần cập nhật gần nhất</h3>
        <p><?php echo e($quanlysach->updated_at); ?></p>
    </div>

    <div>
        <h3>Ảnh sản phẩm</h3>
        <img src="<?php echo e(Storage::disk('AnhSach')->url($quanlysach->AnhSP)); ?>" alt="">
    </div><br>

    <a href="<?php echo e(url('quanlysach')); ?>" class="btn btn-primary">Back</a>
</div>    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/quanlysach/show.blade.php ENDPATH**/ ?>