

<?php $__env->startSection('content'); ?>
    <div class="tab-pane fade show active" id="quanlysach" role="tabpanel" aria-labelledby="v-pills-home-tab">

        <div>
            <div>
                <h1 class="text-center">Danh sách sản phẩm</h1>
                <div>
                    <a href="<?php echo e(url('quanlysach/create')); ?>" class="btn btn-success">+ Thêm mới</a>
                </div>
            </div><br>

            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th scope="col">STT</th>
                        <th scope="col">Tên sách</th>
                        <th scope="col">Tác giả</th>
                        <th scope="col">Thể loại</th>
                        <th scope="col">Đơn giá</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ListSach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($Sach->STT); ?></td>
                            <td scope="row"><?php echo e($Sach->TenSach); ?></td>
                            <td scope="row"><?php echo e($Sach->TacGia); ?></td>
                            <td scope="row"><?php echo e($Sach->TheLoai); ?></td>
                            <td scope="row"><?php echo e(number_format($Sach->DonGia, 0, '', '.')); ?></td>
                            <td>
                                <a href="<?php echo e(url('quanlysach/' . $Sach->STT)); ?>"><i class="far fa-eye"></i></a>
                                <a href="<?php echo e(url('quanlysach/' . $Sach->STT . '/edit')); ?>"><i class="fas fa-pencil-alt"></i></a>
                                <form action="<?php echo e(url('quanlysach/' . $Sach->STT)); ?>" class="d-inline" method="POST"
                                    onsubmit="return confirm('Bạn có chắc chắn xóa')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" style="border: none;
                            background-color: WHITE; color:#007bff;"><i class="fas fa-trash"></i></a></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($ListSach->links('pagination::bootstrap-4')); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/backend/quanlysach/index.blade.php ENDPATH**/ ?>