

<?php $__env->startSection('content'); ?>
    <div class="tab-pane fade show active" id="quanlyuser" role="tabpanel" aria-labelledby="v-pills-home-tab">
        <div>
            <div>
                <h1 class="text-center">Danh sách người dùng</h1>
            </div><br>

            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th scope="col">Tài khoản</th>
                        <th scope="col">Tên hiển thị</th>
                        <th scope="col">Phân loại</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $quanlyuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($user->email); ?></td>
                            <td scope="row"><?php echo e($user->name); ?></td>
                            <?php if($user->id_phanquyen == 3): ?>
                                <td scope="row">Master</td>

                            <?php else: ?>
                                <td scope="row"><?php echo e($user->id_phanquyen == 1 ? 'Khách hàng' : 'Admin'); ?></td>
                            <?php endif; ?>
                            <td>
                                <a href="<?php echo e(url('quanlyuser/' . $user->id)); ?>"><i class="far fa-eye"></i></a>
                                <?php if($user->id_phanquyen != 3): ?>
                                    <a href="<?php echo e(url('quanlyuser/' . $user->id)); ?>"
                                        onclick="return confirm('Bạn có chắc chắn muốn xóa dữ liệu này?')"></a>
                                    <form action="<?php echo e(url('quanlyuser/' . $user->id)); ?>" class="d-inline"
                                        method="POST" onsubmit="return confirm('Bạn có chắc chắn xóa')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit" style="border: none;
                              background-color: WHITE; color:#007bff;"><i class="fas fa-trash"></i></a></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($quanlyuser->links('pagination::bootstrap-4')); ?>

        </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/backend/quanlyuser/index.blade.php ENDPATH**/ ?>