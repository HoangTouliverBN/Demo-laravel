<div class=" col-2 ">
    <div class="nav flex-column nav-pills menu-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">


        <a class=" nav-link border border-primary menu-custom-children"  href="<?php echo e(url('quanlysach')); ?>" role="tab" >Quản lý sách</a>



        <a class=" nav-link border border-primary menu-custom-children"  href="<?php echo e(url('quanlytheloai')); ?>" role="tab">Quản lý thể loại</a>

        <a class=" nav-link border border-primary menu-custom-children"  href="<?php echo e(url('quanlyorder')); ?>" role="tab">Quản lý đơn đăng ký mua hàng</a>

        <a class=" nav-link border border-primary menu-custom-children"  href="<?php echo e(url('quanlyuser')); ?>" role="tab">Quản lý người dùng</a>

        <a class=" nav-link border border-primary menu-custom-children"  href="<?php echo e(url('shoppingCart')); ?>" role="tab">Quản lý giỏ hàng</a>

        <a class=" nav-link border border-primary menu-custom-children"  href="<?php echo e(url('quanlydoanhthu')); ?>" role="tab">Quản lý doanh thu</a>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\Demo-laravel\NguyenHoang\resources\views/frontend/layout/menuAdmin.blade.php ENDPATH**/ ?>